import React, { useState, useCallback, useEffect, useMemo } from 'react';
import DayPicker, { DayModifiers } from 'react-day-picker';
import 'react-day-picker/lib/style.css';
import { isToday, format, parseISO, isAfter } from 'date-fns';
import ptBR from 'date-fns/locale/pt-BR';
import { Link } from 'react-router-dom';
import { FiPower, FiClock } from 'react-icons/fi';

import {
  Container,
  Header,
  HeaderContent,
  Menu,
  AppPresentation,
  AppPresentationTextContainer,
  FeaturesContainer,
  FeaturesLeftColumn,
  FeaturesRightColumn,
  MembersContainer,
  MemberCard,
  Footer,
  ProjectContent,
} from './styles';

import logoImg from '../../assets/solidarize.png';
import appPresentation from '../../assets/app_presentation.png';
import initialScreen from '../../assets/initialScreen.png';
import cadastroScreen from '../../assets/cadastroScreen.png';

import thaji from '../../assets/thaji.jpg';
import john from '../../assets/john.jpg';
import will from '../../assets/will.jpg';
import well from '../../assets/well.jpg';

const Dashboard: React.FC = () => {
  const imagesFeatures = [initialScreen, cadastroScreen];
  const [currentFeature, setCurrentFeature] = useState(0);

  return (
    <Container>
      <Header>
        <HeaderContent>
          <div>
            <img src={logoImg} alt="Solidarize" />
            {/* <h3>Solidarize</h3> */}
          </div>
          <Menu>
            <div>
              <a>Projeto</a>
              <a>Funcionalidades</a>
              <a>Equipe</a>
            </div>
          </Menu>
        </HeaderContent>
        <AppPresentation>
          <AppPresentationTextContainer>
            <p>APOIE</p>
            <p>PARTICIPE</p>
            <p>IDEALIZE</p>
          </AppPresentationTextContainer>
          <img src={appPresentation} alt="Solidarize" />
        </AppPresentation>
      </Header>
      <ProjectContent>
        <h2>O Projeto</h2>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore,
          voluptatibus nostrum labore asperiores nesciunt corrupti veniam, dolor
          quas dignissimos dolorem placeat possimus rem. Alias est doloremque
          amet nesciunt ab vero. Lorem ipsum dolor sit amet consectetur
          adipisicing elit. Inventore, voluptatibus nostrum labore asperiores
          nesciunt corrupti veniam, dolor quas dignissimos dolorem placeat
          possimus rem. Alias est doloremque amet nesciunt ab vero.
        </p>
      </ProjectContent>
      <MembersContainer>
        <h2>Equipe do projeto</h2>
        <div>
          <MemberCard>
            <h3>John Kleber</h3>
            <img src={john} alt="John Kleber" />
            <p>Desenvolvedor Back-end</p>
          </MemberCard>
          <MemberCard>
            <h3>Wellington Gomes</h3>
            <img src={well} alt="Wellington Gomes" />
            <p>Desenvolvedor Front-end</p>
          </MemberCard>
          <MemberCard>
            <h3>Willian Gomes</h3>
            <img src={will} alt="Willian Gomes" />
            <p>Documentação e processos</p>
          </MemberCard>
          <MemberCard>
            <h3>Thajinara Kemy</h3>
            <img src={thaji} alt="Thajinara Kemy" />
            <p>Orientadora</p>
          </MemberCard>
        </div>
      </MembersContainer>
      <FeaturesContainer>
        <h2>Funcionalidades</h2>
        <div>
          <FeaturesLeftColumn>
            <div>
              <button type="button" onClick={() => setCurrentFeature(0)}>
                Cadastro Simplificado
                <span>
                  <FiPower size={22} />
                </span>
              </button>
              <button type="button" onClick={() => setCurrentFeature(1)}>
                Login Fácil
                <span>
                  <FiPower size={22} />
                </span>
              </button>
              <button type="button" onClick={() => setCurrentFeature(0)}>
                Crie campanhas
                <span>
                  <FiPower size={22} />
                </span>
              </button>
              <button type="button" onClick={() => setCurrentFeature(1)}>
                Receba doações
                <span>
                  <FiPower size={22} />
                </span>
              </button>
            </div>
          </FeaturesLeftColumn>
          <img src={imagesFeatures[currentFeature]} alt="Solidarize" />

          <FeaturesRightColumn>
            <div>
              <button type="button" onClick={() => setCurrentFeature(0)}>
                <span>
                  <FiPower size={22} />
                </span>
                Realize doações
              </button>
              <button type="button" onClick={() => setCurrentFeature(0)}>
                <span>
                  <FiPower size={22} />
                </span>
                Divulgue suas necessidades
              </button>
              <button type="button" onClick={() => setCurrentFeature(0)}>
                <span>
                  <FiPower size={22} />
                </span>
                Busque causas próximas
              </button>
              <button type="button" onClick={() => setCurrentFeature(0)}>
                <span>
                  <FiPower size={22} />
                </span>
                Personalize seu perfil
              </button>
            </div>
          </FeaturesRightColumn>
        </div>
      </FeaturesContainer>
      <Footer>
        <img src={logoImg} alt="Solidarize" />
        <h3>Solidarize</h3>
      </Footer>
    </Container>
  );
};

export default Dashboard;

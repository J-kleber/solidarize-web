import styled from 'styled-components';
import { shade } from 'polished';

export const Container = styled.div``;

export const Header = styled.header`
  padding: 32px 0;
  background-image: linear-gradient(to right, #1b3d5e 100%, #1f476d 53%);
  height: 670px;
`;

export const HeaderContent = styled.div`
  max-width: 1120px;
  margin: 0 auto;
  display: flex;
  align-items: center;

  div {
    > img {
      height: 100px;
    }
    h3 {
      text-align: center;
      font-weight: 400;
    }
  }

  button {
    margin-left: auto;
    background: transparent;
    border: 0;
  }

  svg {
    color: #999591;
    width: 20px;
    height: 20px;
  }
`;

export const Menu = styled.div`
  display: flex;
  align-items: center;
  flex: 1;

  img {
    width: 56px;
    height: 56px;
    border-radius: 50%;
  }

  div {
    display: flex;
    flex-direction: row;

    line-height: 24px;
    text-align: center;
    flex-direction: row;
    margin: auto;
    line-height: 24px;
    text-align: center;
    span {
      color: #f4ede8;
    }

    a {
      color: #f4ede8;
      text-decoration: none;
      font-size: 30px;
      padding-right: 25px;

      cursor: pointer;
      &:hover {
        opacity: 0.8;
      }
    }

    a + a {
      border-left: 2px solid;
      padding-left: 25px;
    }
  }
`;

export const AppPresentation = styled.div`
  display: flex;

  img {
    width: 350px;
    margin-left: auto;
    display: flex;
    margin-right: 200px;
  }
`;

export const AppPresentationTextContainer = styled.div`
  align-self: baseline;
  flex: 1;
  display: flex;

  flex-direction: column;
  align-self: center;
  line-height: 110px;
  p {
    font-family: 'Fredoka One', cursive;
    font-size: 50px;
    text-align: center;
  }
  img {
    width: 200px;
  }
`;

export const ProjectContent = styled.div`
  text-align: center;
  color: #1b3d5e;
  background: whitesmoke;
  padding: 48px 150px 40px 150px;
  height: 300px;

  h2 {
    font-size: 36px;
    margin-bottom: 20px;
  }

  p {
    font-size: 20px;
  }
`;

export const FeaturesContainer = styled.div`
  background-color: whitesmoke;
  padding: 48px 0px 40px 0px;
  justify-content: center;
  flex: 1;

  div {
    display: flex;
    img {
      width: 300px;
    }
  }

  h2 {
    text-align: center;
    display: block;
    font-size: 30px;
    margin-bottom: 30px;
    color: #1b3d5e;
  }
`;

export const FeaturesLeftColumn = styled.div`
  flex: 1;
  text-align: right;
  flex-direction: row;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  padding-right: 100px;

  div {
    display: flex;
    flex-direction: column;
    align-items: flex-end;

    button {
      border: none;
      background: none;
      align-items: center;
      display: inline-flex;
      font-size: 20px;
      font-weight: bold;
      color: #999591;

      span {
        margin-left: 20px;
        border: 3px solid #1b5e5e;
        padding: 10px;
        border-radius: 30px;
        align-items: center;
        display: inline-flex;

        svg {
          color: #1b5e5e;
        }
      }
    }

    > button {
      margin-top: 50px;
    }
  }
`;

export const FeaturesRightColumn = styled.div`
  flex: 1;
  text-align: right;
  flex-direction: row;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  padding-left: 100px;

  div {
    display: flex;
    flex-direction: column;
    align-items: flex-start;

    button {
      border: none;
      background: none;
      align-items: center;
      display: inline-flex;
      font-size: 20px;
      font-weight: bold;
      color: #999591;

      span {
        margin-right: 20px;
        border: 3px solid #1b5e5e;
        padding: 10px;
        border-radius: 30px;
        align-items: center;
        display: inline-flex;

        svg {
          color: #1b5e5e;
        }
      }
    }

    > button {
      margin-top: 50px;
    }
  }
`;

export const MembersContainer = styled.div`
  flex: 1;
  text-align: right;
  flex-direction: column;
  padding: 20px;
  background: #1b3d5e;
  padding: 48px 0px 40px 0px;

  > div {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  h2 {
    text-align: center;
    display: block;
    font-size: 30px;
    margin-bottom: 30px;
  }
`;

export const MemberCard = styled.div`
  width: 250px;
  justify-content: center;
  margin: 20px 10px 20px 10px;
  border-radius: 10px;
  padding: 10px;

  h3 {
    color: #ffffff;
    font-size: 20px;
    text-align: center;
    margin-bottom: 10px;
  }

  p {
    color: #ffffff;
    font-size: 16px;
    text-align: center;
    margin-top: 10px;
  }

  img {
    width: 150px;
    border-radius: 50%;
    margin: auto;
    display: block;
  }
`;

export const Footer = styled.footer`
  background: #1b3d5e;
  padding: 40px;
  display: block;
  justify-content: center;
  align-items: center;
  margin: auto;

  img {
    width: 250px;
    display: block;
    margin: auto;
  }

  h3 {
    font-size: 36px;
    text-align: center;
  }
`;
